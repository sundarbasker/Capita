import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.scss']
})
export class TaskComponent implements OnInit {
  tasks: any = [];
  objectkey = [];
  taskTable: boolean = true;
  registerForm: FormGroup;
  addRowPop: boolean = false;
  submitted = false;
  updateBoolean = false
  updateKey = ""
  updateId = ""
  addRowPopup() {
    this.addRowPop = true;
  }

  constructor(private data: DataService, private fb: FormBuilder, private router: Router) { }

  userList: any;
  list = '';



  ngOnInit(): void {

    this.onTable()

    this.registerForm = this.fb.group({
      description: "",
      priority: "",
      status: ""
    });

  }

  onTable() {
    this.tasks = []
    fetch(`https://tasksmanager-302f5.firebaseio.com/Task.json`, { method: 'GET' })
      .then(res => {
        return res.json()
      })
      .then(response => {
        console.log('response', response)
        Object.keys(response).map(key => {
          var data = response[key]
          data['key'] = key
          this.tasks.push(data)
        })
        this.updateBoolean = false;
        this.addRowPop = false;
        console.log('tasks', this.tasks)

      })


  }

  onSubmit(value) {

    console.log('value', value)
    var payload = { "id": this.updateBoolean ? this.updateId : this.tasks.length, "priority": value.priority, "description": value.description, "status": value.status }
    if (this.updateBoolean) {
      fetch(`https://tasksmanager-302f5.firebaseio.com/Task/${this.updateKey}.json`, { method: 'PUT', body: JSON.stringify(payload) })
        .then(res => {
          return res.json()
        })
        .then(response => {
          this.onTable()
          this.formReset()
          window.location.reload();
        })
    } else {
      fetch(`https://tasksmanager-302f5.firebaseio.com/Task.json`, { method: 'POST', body: JSON.stringify(payload) })
        .then(res => {
          return res.json()
        })
        .then(response => {
          this.onTable();
          this.formReset()
          console.log(response)
          var a = document.getElementsByClassName('modal-backdrop') as HTMLCollectionOf<HTMLElement>;
          a[0].style.display = "none";
          window.location.reload();
        })

    }


  }

  delete(value) {
    console.log(value)

    fetch(`https://tasksmanager-302f5.firebaseio.com/Task/${value.key}.json`, { method: 'DELETE' })
      .then(res => {
        return res.json();
      })
      .then(response => {
        console.log('list deleted', response);
        this.onTable();
      })

  }

  update(value) {
    console.log(value)
    this.addRowPop = true;
    this.updateBoolean = true
    console.log(this.registerForm)
    this.registerForm.controls.description.setValue(value.description)
    this.registerForm.controls.priority.setValue(value.priority)
    this.registerForm.controls.status.setValue(value.status)
    this.updateKey = value.key
    this.updateId = value.id
  }
  formReset() {
    this.registerForm.reset();
    this.addRowPop = false;
    this.updateKey = ""
    this.updateId = ""
  }



}